import xbmcgui
import webbrowser

def internet(url):
    if xbmc . getCondVisibility ( 'system.platform.android' ) :
        ost = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( ''+url+'' ) )
    else:
        ost = webbrowser . open ( ''+url+'' )   


dialog = xbmcgui.Dialog()
link = dialog.select('Laucher Download de Apps', ['JR PLAY','CYLPLAY / PANDA','APPS','Filelinked [codigo 18755494]','TB RG (Windows Download)','',''])

if link == 0:
    url = "https://sites.google.com/view/jr-apps/jr-play"
    internet(url)

if link == 1:
    url = "https://sites.google.com/view/jr-apps/cylplay-panda"
    internet(url)

if link == 2:
    url = "https://sites.google.com/view/jr-apps/apps"
    internet(url)

if link == 3:
    url = "https://get.droidadmin.com/"
    internet(url)

if link == 4:
    url = "https://tb.rg-adguard.net/public.php"
    internet(url)

if link == 5:
    url = ""
    internet(url)

if link == 6:
    url = ""
    internet(url)

if link == 7:
    url = ""
    internet(url)

if link == 8:
    url = ""
    internet(url)

if link == 9:
    url = ""
    internet(url)

if link == 10:
    url = ""
    internet(url)

if link == 11:
    url = ""
    internet(url)
